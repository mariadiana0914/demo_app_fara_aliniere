package com.example.nr_apasari_buton;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
Button btn;
TextView txv;
int cnt=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn=(Button) findViewById(R.id.button1);
        txv=(TextView) findViewById(R.id.tx);
    }
    public void CountClick(View v){
        cnt++;
        txv.setText("You've hit the button: "+String.valueOf(cnt)+" times");
    }
}

